<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20251010QW extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'QW core tables: ci, questionnaire, item, field, response, answer, attachment, workflow_log, snapshot';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<SQL
CREATE TABLE qw_ci (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  tenant_id BIGINT UNSIGNED NOT NULL,
  ci_key VARCHAR(191) NOT NULL,
  ci_name VARCHAR(255) NOT NULL,
  UNIQUE INDEX uq_tenant_ci (tenant_id, ci_key),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_questionnaire (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  tenant_id BIGINT UNSIGNED NOT NULL,
  ci_id BIGINT UNSIGNED NOT NULL,
  code VARCHAR(64) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description LONGTEXT DEFAULT NULL,
  status ENUM('draft','in_review','approved','archived') NOT NULL DEFAULT 'draft',
  owner_user_id BIGINT UNSIGNED DEFAULT NULL,
  approver_user_id BIGINT UNSIGNED DEFAULT NULL,
  version INT NOT NULL DEFAULT 1,
  is_locked TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE INDEX uq_tenant_code (tenant_id, code),
  INDEX idx_ci (ci_id),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_item (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  questionnaire_id BIGINT UNSIGNED NOT NULL,
  parent_id BIGINT UNSIGNED DEFAULT NULL,
  type ENUM('header','question') NOT NULL,
  title VARCHAR(255) NOT NULL,
  help LONGTEXT DEFAULT NULL,
  sort INT NOT NULL DEFAULT 0,
  outline VARCHAR(64) DEFAULT NULL,
  required TINYINT(1) NOT NULL DEFAULT 0,
  visible_when JSON DEFAULT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  INDEX idx_q_parent_sort (questionnaire_id, parent_id, sort),
  INDEX idx_type (type),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_field (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  item_id BIGINT UNSIGNED NOT NULL,
  ui_type ENUM('input','textarea','wysiwyg','select','multiselect','radio','checkbox','slider','color','date','time','daterange','integer','autocomplete','chainselect','image','file','voice','video','toggle') NOT NULL,
  placeholder VARCHAR(255) DEFAULT NULL,
  default_value LONGTEXT DEFAULT NULL,
  min_value DOUBLE DEFAULT NULL,
  max_value DOUBLE DEFAULT NULL,
  step_value DOUBLE DEFAULT NULL,
  validation_regex VARCHAR(255) DEFAULT NULL,
  options_json JSON DEFAULT NULL,
  options_sql LONGTEXT DEFAULT NULL,
  chain_sql JSON DEFAULT NULL,
  accept_mime VARCHAR(255) DEFAULT NULL,
  max_size_mb INT DEFAULT NULL,
  unique_key VARCHAR(128) DEFAULT NULL,
  INDEX idx_item (item_id),
  INDEX idx_type (ui_type),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_response (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  questionnaire_id BIGINT UNSIGNED NOT NULL,
  submitted_by_user_id BIGINT UNSIGNED DEFAULT NULL,
  status ENUM('in_progress','submitted','approved','rejected') NOT NULL DEFAULT 'in_progress',
  started_at DATETIME NOT NULL,
  submitted_at DATETIME DEFAULT NULL,
  approved_at DATETIME DEFAULT NULL,
  rejected_at DATETIME DEFAULT NULL,
  INDEX idx_qr_q (questionnaire_id),
  INDEX idx_qr_status (status),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_answer (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  response_id BIGINT UNSIGNED NOT NULL,
  item_id BIGINT UNSIGNED NOT NULL,
  field_id BIGINT UNSIGNED DEFAULT NULL,
  value_text LONGTEXT DEFAULT NULL,
  value_json JSON DEFAULT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  INDEX idx_resp_item (response_id, item_id),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_attachment (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  response_id BIGINT UNSIGNED NOT NULL,
  item_id BIGINT UNSIGNED NOT NULL,
  field_id BIGINT UNSIGNED DEFAULT NULL,
  storage_path VARCHAR(512) NOT NULL,
  original_name VARCHAR(255) DEFAULT NULL,
  mime_type VARCHAR(127) DEFAULT NULL,
  size_bytes BIGINT DEFAULT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_resp (response_id),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_workflow_log (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  questionnaire_id BIGINT UNSIGNED NOT NULL,
  response_id BIGINT UNSIGNED DEFAULT NULL,
  actor_user_id BIGINT UNSIGNED NOT NULL,
  action ENUM('submit','request_changes','approve','reject','reopen','archive') NOT NULL,
  comment LONGTEXT DEFAULT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_q (questionnaire_id),
  INDEX idx_r (response_id),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        $this->addSql(<<<SQL
CREATE TABLE qw_questionnaire_snapshot (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  questionnaire_id BIGINT UNSIGNED NOT NULL,
  version INT NOT NULL,
  payload LONGTEXT NOT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_qv (questionnaire_id, version),
  PRIMARY KEY(id)
) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
SQL);

        // FKs (defer for readability)
        $this->addSql('ALTER TABLE qw_questionnaire ADD CONSTRAINT fk_qw_q_ci FOREIGN KEY (ci_id) REFERENCES qw_ci (id)');
        $this->addSql('ALTER TABLE qw_item ADD CONSTRAINT fk_item_q FOREIGN KEY (questionnaire_id) REFERENCES qw_questionnaire (id)');
        $this->addSql('ALTER TABLE qw_item ADD CONSTRAINT fk_item_parent FOREIGN KEY (parent_id) REFERENCES qw_item (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE qw_field ADD CONSTRAINT fk_field_item FOREIGN KEY (item_id) REFERENCES qw_item (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE qw_response ADD CONSTRAINT fk_resp_q FOREIGN KEY (questionnaire_id) REFERENCES qw_questionnaire (id)');
        $this->addSql('ALTER TABLE qw_answer ADD CONSTRAINT fk_ans_resp FOREIGN KEY (response_id) REFERENCES qw_response (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE qw_answer ADD CONSTRAINT fk_ans_item FOREIGN KEY (item_id) REFERENCES qw_item (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE qw_answer ADD CONSTRAINT fk_ans_field FOREIGN KEY (field_id) REFERENCES qw_field (id) ON DELETE SET NULL');
        $this->addSql('ALTER TABLE qw_attachment ADD CONSTRAINT fk_att_resp FOREIGN KEY (response_id) REFERENCES qw_response (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE qw_workflow_log ADD CONSTRAINT fk_wf_q FOREIGN KEY (questionnaire_id) REFERENCES qw_questionnaire (id)');
        $this->addSql('ALTER TABLE qw_questionnaire_snapshot ADD CONSTRAINT fk_snap_q FOREIGN KEY (questionnaire_id) REFERENCES qw_questionnaire (id)');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('SET FOREIGN_KEY_CHECKS=0');
        $this->addSql('DROP TABLE IF EXISTS qw_questionnaire_snapshot');
        $this->addSql('DROP TABLE IF EXISTS qw_workflow_log');
        $this->addSql('DROP TABLE IF EXISTS qw_attachment');
        $this->addSql('DROP TABLE IF EXISTS qw_answer');
        $this->addSql('DROP TABLE IF EXISTS qw_response');
        $this->addSql('DROP TABLE IF EXISTS qw_field');
        $this->addSql('DROP TABLE IF EXISTS qw_item');
        $this->addSql('DROP TABLE IF EXISTS qw_questionnaire');
        $this->addSql('DROP TABLE IF EXISTS qw_ci');
        $this->addSql('SET FOREIGN_KEY_CHECKS=1');
    }
}
