import React, { useEffect, useMemo, useState } from 'react';
import { DndContext, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { getQuestionnaire, addItem, patchItem } from './api';
import type { QuestionnaireDTO, ItemDTO, Id } from './types';

function toTree(items: ItemDTO[]) {
  const map = new Map<Id, any>(); items.forEach(i=>map.set(i.id,{...i, children:[]}));
  const roots: any[] = [];
  items.forEach(i=>{ const n = map.get(i.id); if(i.parentId==null) roots.push(n); else map.get(i.parentId)?.children.push(n);});
  const sortRec=(nodes:any[])=>{nodes.sort((a,b)=>a.sort-b.sort); nodes.forEach((n:any)=>sortRec(n.children));}; sortRec(roots);
  return roots;
}

function Node({n, onAdd, onClick}:{n:any; onAdd:(parentId:Id,type:'header'|'question')=>void; onClick:(id:Id)=>void}){
  return (
    <div className={`rounded-2xl shadow p-3 mb-2 ${n.type==='header'?'bg-white':'bg-gray-50'}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-400 w-14">{n.outline}</span>
          <span className="font-medium">{n.title}</span>
        </div>
        <div className="flex gap-2">
          <button className="px-2 py-1 rounded bg-gray-100" onClick={()=>onAdd(n.id,'header')}>+ Header</button>
          <button className="px-2 py-1 rounded bg-gray-100" onClick={()=>onAdd(n.id,'question')}>+ Question</button>
          <button className="px-2 py-1 rounded bg-gray-100" onClick={()=>onClick(n.id)}>Edit</button>
        </div>
      </div>
      {n.help && <div className="text-xs text-gray-500 mt-1" dangerouslySetInnerHTML={{__html:n.help}} />}
      {n.children?.length>0 && (
        <div className="ml-6 mt-2 border-l pl-3">
          {n.children.map((c:any)=>(<Node key={c.id} n={c} onAdd={onAdd} onClick={onClick} />))}
        </div>
      )}
    </div>
  );
}

export default function QuestionnaireBuilder({qid}:{qid:number}){
  const sensors = useSensors(useSensor(PointerSensor));
  const [q, setQ] = useState<QuestionnaireDTO|null>(null);
  const [sel, setSel] = useState<Id|null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(()=>{ getQuestionnaire(qid).then(setQ); },[qid]);
  const tree = useMemo(()=> q? toTree(q.items):[], [q]);

  async function handleAdd(parentId:Id, type:'header'|'question'){
    if(!q) return; setBusy(true);
    const res = await addItem(q.id, { parentId, type, title: type==='header'? 'New Section':'New Question', sort: 999 });
    const fresh = await getQuestionnaire(qid); setQ(fresh); setBusy(false);
  }

  async function handleDrop(ev: DragEndEvent){ /* placeholder for full drag sorting of siblings */ }

  function openInspector(id:Id){ setSel(id); }
  const selected = q?.items.find(i=>i.id===sel) || null;

  async function saveInspector(upd:Partial<ItemDTO>){ if(!selected) return; setBusy(true); await patchItem(Number(selected.id), upd); const fresh=await getQuestionnaire(qid); setQ(fresh); setBusy(false); }

  return (
    <div className="grid grid-cols-12 gap-4 p-4">
      <div className="col-span-8">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-2xl font-semibold">{q?.title ?? 'Questionnaire'}</h1>
          <div className="flex gap-2">
            <button className="px-3 py-2 rounded-2xl shadow bg-white" onClick={()=>handleAdd(null as any,'header')}>+ Header</button>
            <button className="px-3 py-2 rounded-2xl shadow bg-white" onClick={()=>handleAdd(null as any,'question')}>+ Question</button>
          </div>
        </div>
        <DndContext sensors={sensors} onDragEnd={handleDrop}>
          <div>
            {tree.map((n:any)=>(<Node key={n.id} n={n} onAdd={handleAdd} onClick={openInspector} />))}
          </div>
        </DndContext>
      </div>

      <div className="col-span-4">
        <div className="rounded-2xl shadow p-4 bg-white sticky top-4">
          <h2 className="text-lg font-medium mb-2">Inspector</h2>
          {!selected && <p className="text-sm text-gray-500">Select a node to edit.</p>}
          {selected && (
            <Inspector item={selected} onSave={saveInspector} />
          )}
          {busy && <div className="mt-3 text-xs text-gray-400">Saving…</div>}
        </div>
      </div>
    </div>
  );
}

function Inspector({item, onSave}:{item:ItemDTO; onSave:(upd:Partial<ItemDTO>)=>void}){
  const [title, setTitle] = useState(item.title);
  const [required, setRequired] = useState(!!item.required);
  const [help, setHelp] = useState(item.help || '');

  return (
    <div className="space-y-3">
      <div>
        <label className="text-xs text-gray-500">Outline</label>
        <div className="text-sm">{item.outline || '—'}</div>
      </div>
      <div>
        <label className="text-xs text-gray-500">Title</label>
        <input className="w-full border rounded p-2" value={title} onChange={e=>setTitle(e.target.value)} />
      </div>
      <div>
        <label className="text-xs text-gray-500">Help (HTML allowed)</label>
        <textarea className="w-full border rounded p-2 h-24" value={help} onChange={e=>setHelp(e.target.value)} />
      </div>
      <div className="flex items-center gap-2">
        <input type="checkbox" checked={required} onChange={e=>setRequired(e.target.checked)} />
        <span className="text-sm">Required</span>
      </div>
      <div className="flex gap-2">
        <button className="px-3 py-2 rounded bg-gray-100" onClick={()=>onSave({title, help, required})}>Save</button>
      </div>
    </div>
  );
}
