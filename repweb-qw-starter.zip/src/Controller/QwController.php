<?php
namespace App\Controller;

use App\Entity\{QwQuestionnaire,QwItem,QwItemType,QwField,QwUiType,QwCi};
use App\Service\QwOutlineNumberingService;
use Doctrine\ORM\EntityManagerInterface as EM;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\{JsonResponse, Request};
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api/qw')]
class QwController extends AbstractController
{
    public function __construct(private EM $em, private QwOutlineNumberingService $numbering) {}

    #[Route('/questionnaires', methods: ['POST'])]
    public function createQuestionnaire(Request $req): JsonResponse
    {
        $p = $req->toArray();
        $q = new QwQuestionnaire();
        $q->setTenantId($p['tenant_id']);
        $q->setCode($p['code']);
        $q->setTitle($p['title']);
        $q->setDescription($p['description'] ?? null);
        if (!empty($p['ci_id'])) {
            $q->setCi($this->em->getReference(QwCi::class, $p['ci_id']));
        } else {
            // for quick testing create a dummy CI  (remove in production)
            $ci = new QwCi(); $ci->setTenantId($p['tenant_id']); $ci->setCiKey('dummy'); $ci->setCiName('Dummy CI');
            $this->em->persist($ci); $this->em->flush();
            $q->setCi($ci);
        }
        $this->em->persist($q); $this->em->flush();
        return $this->json(['id'=>$q->getId()]);
    }

    #[Route('/questionnaires/{id}', methods:['GET'])]
    public function getQuestionnaire(int $id): JsonResponse
    {
        $q = $this->em->getRepository(QwQuestionnaire::class)->find($id);
        $items = $this->em->getRepository(QwItem::class)->createQueryBuilder('i')
            ->where('IDENTITY(i.questionnaire)=:id')->setParameter('id',$id)
            ->orderBy('i.parent','ASC')->addOrderBy('i.sort','ASC')->getQuery()->getResult();
        $payload = [
            'id'=>$q->getId(), 'title'=>$q->getTitle(), 'status'=>$q->getStatus()->value,
            'items'=> array_map(fn(QwItem $i)=>[
                'id'=>$i->getId(),'parentId'=>$i->getParent()?->getId(),'type'=>$i->getType()->value,
                'title'=>$i->getTitle(),'help'=>$i->getHelp(),'sort'=>$i->getSort(),'outline'=>$i->getOutline(),
                'required'=>$i->isRequired(),'visibleWhen'=>$i->getVisibleWhen()
            ], $items)
        ];
        return $this->json($payload);
    }

    #[Route('/questionnaires/{id}/items', methods:['POST'])]
    public function addItem(int $id, Request $req): JsonResponse
    {
        $p = $req->toArray();
        $item = new QwItem();
        $item->setQuestionnaire($this->em->getReference(QwQuestionnaire::class,$id));
        $item->setParent(isset($p['parentId'])? $this->em->getReference(QwItem::class,$p['parentId']) : null);
        $item->setType(QwItemType::from($p['type']));
        $item->setTitle($p['title']);
        $item->setHelp($p['help'] ?? null);
        $item->setSort($p['sort'] ?? 0);
        $item->setRequired((bool)($p['required'] ?? false));
        $item->setVisibleWhen($p['visibleWhen'] ?? null);
        $this->em->persist($item); $this->em->flush();
        $this->numbering->rebuild($id);
        return $this->json(['id'=>$item->getId()]);
    }

    #[Route('/items/{id}', methods:['PATCH'])]
    public function updateItem(int $id, Request $req): JsonResponse
    {
        $p = $req->toArray();
        $item = $this->em->getRepository(QwItem::class)->find($id);
        if(isset($p['title'])) $item->setTitle($p['title']);
        if(array_key_exists('parentId',$p)) $item->setParent($p['parentId']? $this->em->getReference(QwItem::class,$p['parentId']):null);
        if(isset($p['sort'])) $item->setSort((int)$p['sort']);
        if(isset($p['visibleWhen'])) $item->setVisibleWhen($p['visibleWhen']);
        $this->em->flush();
        $this->numbering->rebuild($item->getQuestionnaire()->getId());
        return $this->json(['ok'=>true]);
    }

    #[Route('/items/{id}/fields', methods:['POST'])]
    public function addField(int $id, Request $req): JsonResponse
    {
        $p = $req->toArray();
        $f = new QwField();
        $f->setItem($this->em->getReference(QwItem::class,$id));
        $f->setUiType(QwUiType::from($p['ui_type']));
        $f->setPlaceholder($p['placeholder'] ?? null);
        $f->setDefaultValue($p['default_value'] ?? null);
        $f->setMinValue($p['min_value'] ?? null);
        $f->setMaxValue($p['max_value'] ?? null);
        $f->setStepValue($p['step_value'] ?? null);
        $f->setValidationRegex($p['validation_regex'] ?? null);
        $f->setOptionsJson($p['options_json'] ?? null);
        $f->setOptionsSql($p['options_sql'] ?? null);
        $f->setChainSql($p['chain_sql'] ?? null);
        $f->setAcceptMime($p['accept_mime'] ?? null);
        $f->setMaxSizeMb($p['max_size_mb'] ?? null);
        $f->setUniqueKey($p['unique_key'] ?? null);
        $this->em->persist($f); $this->em->flush();
        return $this->json(['id'=>$f->getId()]);
    }

    #[Route('/rebuild-outline/{qid}', methods:['POST'])]
    public function rebuild(int $qid): JsonResponse { $this->numbering->rebuild($qid); return $this->json(['ok'=>true]); }
}
