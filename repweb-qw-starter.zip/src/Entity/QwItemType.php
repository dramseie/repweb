<?php
namespace App\Entity;

enum QwItemType: string { case Header='header'; case Question='question'; }
