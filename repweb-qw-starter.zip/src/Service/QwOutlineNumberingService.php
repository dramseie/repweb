<?php
namespace App\Service;

use App\Entity\QwItem;
use Doctrine\ORM\EntityManagerInterface;

class QwOutlineNumberingService
{
    public function __construct(private EntityManagerInterface $em) {}

    /** Rebuild hierarchical outline for a questionnaire */
    public function rebuild(int|string $questionnaireId): void
    {
        $repo = $this->em->getRepository(QwItem::class);
        $items = $repo->createQueryBuilder('i')
            ->where('IDENTITY(i.questionnaire) = :qid')
            ->setParameter('qid', $questionnaireId)
            ->orderBy('i.parent','ASC')->addOrderBy('i.sort','ASC')->getQuery()->getResult();

        // Build adjacency list
        $byParent = [];
        foreach ($items as $it) {
            $pid = $it->getParent()?->getId();
            $byParent[$pid][] = $it;
        }

        $walk = function($parentId, array $prefix) use (&$walk, &$byParent) {
            $i=1;
            foreach ($byParent[$parentId] ?? [] as $node) {
                $node->setOutline(implode('.', array_merge($prefix, [$i])));
                $this->em->persist($node);
                $walk($node->getId(), array_merge($prefix, [$i]));
                $i++;
            }
        };
        $walk(null, []);
        $this->em->flush();
    }
}
