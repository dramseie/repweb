<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'report_tile')]
#[ORM\HasLifecycleCallbacks]
class ReportTile
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(length: 180)]
    private string $title;

    // e.g. link | grafana | datatable | plotly | pivot | iframe | image | text
    #[ORM\Column(length: 50)]
    private string $type;

    #[ORM\Column(type: 'json', nullable: true)]
    private ?array $config = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $thumbnailUrl = null;

    #[ORM\Column(type: 'json', nullable: true)]
    private ?array $allowedRoles = null;

    #[ORM\Column(type: 'boolean')]
    private bool $isActive = true;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeImmutable $updatedAt;

    public function __construct()
    {
        $now = new \DateTimeImmutable();
        $this->createdAt = $now;
        $this->updatedAt = $now;
    }

    #[ORM\PreUpdate]
    public function touch(): void { $this->updatedAt = new \DateTimeImmutable(); }

    // Getters / setters
    public function getId(): ?int { return $this->id; }
    public function getTitle(): string { return $this->title; }
    public function setTitle(string $v): self { $this->title=$v; return $this; }
    public function getType(): string { return $this->type; }
    public function setType(string $v): self { $this->type=$v; return $this; }
    public function getConfig(): ?array { return $this->config; }
    public function setConfig(?array $v): self { $this->config=$v; return $this; }
    public function getThumbnailUrl(): ?string { return $this->thumbnailUrl; }
    public function setThumbnailUrl(?string $v): self { $this->thumbnailUrl=$v; return $this; }
    public function getAllowedRoles(): ?array { return $this->allowedRoles; }
    public function setAllowedRoles(?array $v): self { $this->allowedRoles=$v; return $this; }
    public function isActive(): bool { return $this->isActive; }
    public function setIsActive(bool $v): self { $this->isActive=$v; return $this; }
    public function getCreatedAt(): \DateTimeImmutable { return $this->createdAt; }
    public function getUpdatedAt(): \DateTimeImmutable { return $this->updatedAt; }
}
