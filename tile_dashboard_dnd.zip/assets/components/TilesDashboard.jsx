import React, { useEffect, useMemo, useState } from 'react';
import { Api } from './api';
import TileCard from './TileCard';
import AddTileModal from './AddTileModal';

export default function TilesDashboard() {
  const [allTiles, setAllTiles] = useState([]);
  const [myTiles, setMyTiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [error, setError] = useState(null);

  async function refresh() {
    setLoading(true);
    try {
      const [a, m] = await Promise.all([Api.getAllTiles(), Api.getMyTiles()]);
      setAllTiles(a); setMyTiles(m);
      setError(null);
    } catch (e) { setError(String(e.message || e)); }
    setLoading(false);
  }

  useEffect(() => { refresh(); }, []);

  async function addTile(tileId) {
    try { await Api.addUserTile(tileId); await refresh(); setShowAdd(false); } catch (e) { alert(e.message || e); }
  }

  async function removeTile(userTileId) {
    if (!confirm('Remove this tile?')) return;
    try { await Api.removeUserTile(userTileId); setMyTiles(myTiles.filter(x => x.id !== userTileId)); } catch (e) { alert(e.message || e); }
  }

  const sorted = useMemo(() => {
    return [...myTiles].sort((a, b) => (b.pinned - a.pinned) || (a.position - b.position));
  }, [myTiles]);

  useEffect(() => {
    const btn = document.getElementById('btn-open-add');
    const handler = () => setShowAdd(true);
    if (btn) btn.addEventListener('click', handler);
    return () => { if (btn) btn.removeEventListener('click', handler); }
  }, []);

  if (loading) return <div>Loading…</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  return (
    <>
      <div className="tiles-grid">
        {sorted.map(ut => (
          <TileCard key={ut.id} userTile={ut} onRemove={removeTile} />
        ))}
        {sorted.length === 0 && <div className="text-muted">No tiles yet. Click “Add tiles”.</div>}
      </div>

      {showAdd && (
        <AddTileModal
          allTiles={allTiles}
          myTiles={myTiles}
          onAdd={addTile}
          onClose={() => setShowAdd(false)}
        />
      )}
    </>
  );
}

// Optional mount helper if you bootstrap from app.js
export function mountTilesDashboard() {
  const rootEl = document.getElementById('react-tiles-dashboard');
  if (!rootEl) return;
  const { createRoot } = require('react-dom/client');
  const root = createRoot(rootEl);
  root.render(<TilesDashboard />);
}
