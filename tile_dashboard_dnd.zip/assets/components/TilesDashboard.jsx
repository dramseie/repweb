import React, { useCallback, useEffect, useMemo, useState } from 'react';
import GridLayout from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import { Api } from './api';
import TileCard from './TileCard';

// Default grid config
const COLS = 12;
const ROW_HEIGHT = 30; // px per row

function toLayout(userTile, idx) {
  // userTile.layout may contain {x,y,w,h}. Fallback defaults.
  const l = userTile.layout || {};
  const w = Math.max(3, Math.min(6, parseInt(l.w || 4, 10)));
  const h = Math.max(4, Math.min(12, parseInt(l.h || 6, 10)));
  const x = Math.max(0, Math.min(COLS - w, parseInt(l.x ?? ((idx * 4) % COLS), 10)));
  const y = parseInt(l.y ?? Infinity, 10); // Infinity = put it at the bottom
  return { i: String(userTile.id), x, y, w, h, minW: 3, minH: 3 };
}

export default function TilesDashboard() {
  const [allTiles, setAllTiles] = useState([]);
  const [myTiles, setMyTiles] = useState([]);
  const [layout, setLayout] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [error, setError] = useState(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [a, m] = await Promise.all([Api.getAllTiles(), Api.getMyTiles()]);
      setAllTiles(a); setMyTiles(m);
      setLayout(m.map(toLayout));
      setError(null);
    } catch (e) { setError(String(e.message || e)); }
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  async function addTile(tileId) {
    try { await Api.addUserTile(tileId); await refresh(); setShowAdd(false); } catch (e) { alert(e.message || e); }
  }

  async function removeTile(userTileId) {
    if (!confirm('Remove this tile?')) return;
    try { await Api.removeUserTile(userTileId); setMyTiles(prev => prev.filter(x => x.id !== userTileId)); setLayout(prev => prev.filter(l => l.i !== String(userTileId))); } catch (e) { alert(e.message || e); }
  }

  const onLayoutChange = useCallback(async (newLayout) => {
    setLayout(newLayout);
    // Persist each changed item to server (debounced in real apps)
    try {
      await Promise.all(newLayout.map(l => {
        const id = parseInt(l.i, 10);
        const payload = { x: l.x, y: l.y, w: l.w, h: l.h };
        return Api.updateLayout(id, payload);
      }));
    } catch (e) {
      console.warn('Layout save failed', e);
    }
  }, []);

  const sorted = useMemo(() => {
    return [...myTiles].sort((a, b) => (b.pinned - a.pinned) || (a.position - b.position));
  }, [myTiles]);

  useEffect(() => {
    const btn = document.getElementById('btn-open-add');
    const handler = () => setShowAdd(true);
    if (btn) btn.addEventListener('click', handler);
    return () => { if (btn) btn.removeEventListener('click', handler); };
  }, []);

  if (loading) return <div>Loading…</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  const layoutMap = new Map(layout.map(l => [l.i, l]));

  return (
    <>
      <GridLayout
        className="layout"
        cols={COLS}
        rowHeight={ROW_HEIGHT}
        width={1200}
        isResizable
        isDraggable
        onLayoutChange={onLayoutChange}
        layout={sorted.map((ut, idx) => layoutMap.get(String(ut.id)) || toLayout(ut, idx))}
        compactType="vertical"
        margin={[16, 16]}
        containerPadding={[0, 0]}
      >
        {sorted.map(ut => (
          <div key={String(ut.id)} data-grid={layoutMap.get(String(ut.id)) || toLayout(ut, 0)}>
            <TileCard userTile={ut} onRemove={removeTile} />
          </div>
        ))}
      </GridLayout>

      {showAdd && (
        <AddTileModal
          allTiles={allTiles}
          myTiles={myTiles}
          onAdd={addTile}
          onClose={() => setShowAdd(false)}
        />
      )}
    </>
  );
}

// Keep AddTileModal import for modal rendering
import AddTileModal from './AddTileModal';
