
# Symfony Reporting Scaffold (EasyAdmin + DataTables + Plotly + Grafana + React)
... (truncated in README for brevity in this note; full instructions inline in project)
