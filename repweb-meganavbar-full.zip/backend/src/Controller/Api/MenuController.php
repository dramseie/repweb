<?php

namespace App\Controller\Api;

use App\Service\MenuBuilder;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api', name: 'api_')]
class MenuController extends AbstractController
{
    #[Route('/menu', name: 'menu', methods: ['GET'])]
    public function menu(MenuBuilder $menu): Response
    {
        return $this->json($menu->getMenuTree());
    }
}
